using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace solar_system
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        Texture2D sun, mercury, venus, earth, mars, jupiter, saturn, uranus, neptune;
        float sun_radius, mercury_radius, venus_radius, earth_radius, mars_radius, jupiter_radius, saturn_radius, uranus_radius, neptune_radius,
             mercury_dist, venus_dist, earth_dist, mars_dist, jupiter_dist, saturn_dist, uranus_dist, neptune_dist, 
             mercury_orbit, venus_orbit, earth_orbit, mars_orbit, jupiter_orbit, saturn_orbit, uranus_orbit, neptune_orbit;
        Vector2 sun_v2, mercury_v2, venus_v2, earth_v2, mars_v2, jupiter_v2, saturn_v2, uranus_v2, neptune_v2;
        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            graphics.IsFullScreen = true;
            Content.RootDirectory = "Content";
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here
            int sizeRedux = 100;
            int distRedux = 5000;
            int orbRedux = 1000;

            //sun is reduced by 2 digit befor size reduction
            sun_radius = 6950 / sizeRedux;
            mercury_radius = 2440 / sizeRedux;
            venus_radius = 6052 / sizeRedux;
            earth_radius = 6378 / sizeRedux;
            mars_radius = 3397 / sizeRedux;
            //jupiter,saturn,uranus,neptune is reduced by 1 befor size reduction
            jupiter_radius = 7149 / sizeRedux;
            saturn_radius = 6026 / sizeRedux;
            uranus_radius = 2555 / sizeRedux;
            neptune_radius = 2476 / sizeRedux;

            //starting value reduced by 2 digit befor distence reduction
            mercury_dist = 579100 / distRedux;
            venus_dist = 1082000 / distRedux;
            earth_dist = 1496000 / distRedux;
            mars_dist = 2279400 / distRedux;
            jupiter_dist = 77833000 / distRedux;
            saturn_dist = 142460000 / distRedux;
            uranus_dist = 28735500 / distRedux;
            neptune_dist = 45010000 / distRedux;

            mercury_orbit = (float)47.8 / orbRedux;
            venus_orbit = (float)35.02 / orbRedux;
            earth_orbit = (float)29.78 / orbRedux;
            mars_orbit = (float)24.077 / orbRedux;
            jupiter_orbit = (float)13.07 / orbRedux;
            saturn_orbit = (float)9.69 / orbRedux;
            uranus_orbit = (float)6.81 / orbRedux;
            neptune_orbit = (float)5.43 / orbRedux;

            sun_v2 = new Vector2(Window.ClientBounds.Width / 2, Window.ClientBounds.Height / 2);
            mercury_v2 = new Vector2(sun_v2.X + mercury_dist, sun_v2.Y);
            venus_v2 = new Vector2(sun_v2.X + venus_dist, sun_v2.Y);
            earth_v2 = new Vector2(sun_v2.X + earth_dist, sun_v2.Y);
            mars_v2 = new Vector2(sun_v2.X + mars_dist, sun_v2.Y);
            jupiter_v2 = new Vector2(sun_v2.X + jupiter_dist, sun_v2.Y);
            saturn_v2 = new Vector2(sun_v2.X + saturn_dist, sun_v2.Y);
            uranus_v2 = new Vector2(sun_v2.X + uranus_dist, sun_v2.Y);
            neptune_v2 = new Vector2(sun_v2.X + neptune_dist, sun_v2.Y);
            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            // TODO: use this.Content to load your game content here
            sun = Content.Load<Texture2D>(@"image/sun");
            mercury = Content.Load<Texture2D>(@"image/mercury");
            venus = Content.Load<Texture2D>(@"image/venus");
            earth = Content.Load<Texture2D>(@"image/earth");
            mars = Content.Load<Texture2D>(@"image/mars");
            jupiter = Content.Load<Texture2D>(@"image/jupiter");
            saturn = Content.Load<Texture2D>(@"image/saturn");
            uranus = Content.Load<Texture2D>(@"image/uranus");
            neptune = Content.Load<Texture2D>(@"image/neptune");
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            // Allows the game to exit
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed)
                this.Exit();

            // TODO: Add your update logic here
            mercury_v2 = RotateAboutOrigin(mercury_v2, sun_v2, mercury_orbit);
            venus_v2 = RotateAboutOrigin(venus_v2, sun_v2, venus_orbit);
            earth_v2 = RotateAboutOrigin(earth_v2, sun_v2, earth_orbit);
            mars_v2 = RotateAboutOrigin(mars_v2, sun_v2, mars_orbit);
            jupiter_v2 = RotateAboutOrigin(jupiter_v2, sun_v2, jupiter_orbit);
            saturn_v2 = RotateAboutOrigin(saturn_v2, sun_v2, saturn_orbit);
            uranus_v2 = RotateAboutOrigin(uranus_v2, sun_v2, uranus_orbit);
            neptune_v2 = RotateAboutOrigin(neptune_v2, sun_v2, neptune_orbit);


            base.Update(gameTime);
        }

        //handles the orbits of planits
        private Vector2 RotateAboutOrigin(Vector2 point, Vector2 origin, float rotation)
        {
            return Vector2.Transform(point - origin, Matrix.CreateRotationZ(rotation)) + origin;
        }

        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.Black);

            // TODO: Add your drawing code here
            spriteBatch.Begin();
            spriteBatch.Draw(sun, new Vector2(sun_v2.X - sun_radius, sun_v2.Y - sun_radius), Color.White);
            spriteBatch.Draw(mercury, new Vector2(mercury_v2.X - mercury_radius, mercury_v2.Y - mercury_radius), Color.White);
            spriteBatch.Draw(venus, new Vector2(venus_v2.X - venus_radius, venus_v2.Y - venus_radius), Color.White);
            spriteBatch.Draw(earth, new Vector2(earth_v2.X - earth_radius, earth_v2.Y - earth_radius), Color.White);
            spriteBatch.Draw(mars, new Vector2(mars_v2.X - mars_radius, mars_v2.Y - mars_radius), Color.White);
            spriteBatch.Draw(jupiter, new Vector2(jupiter_v2.X - jupiter_radius, jupiter_v2.Y - jupiter_radius), Color.White);
            spriteBatch.Draw(saturn, new Vector2(saturn_v2.X - saturn_radius, saturn_v2.Y - saturn_radius), Color.White);
            spriteBatch.Draw(uranus, new Vector2(uranus_v2.X - uranus_radius, uranus_v2.Y - uranus_radius), Color.White);
            spriteBatch.Draw(neptune, new Vector2(neptune_v2.X - neptune_radius, neptune_v2.Y - neptune_radius), Color.White);
            spriteBatch.End();
            base.Draw(gameTime);
        }
    }
}
